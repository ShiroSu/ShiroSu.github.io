window.onload=function() {
  var arrow=document.querySelector(".arrow");
  var arrow_wrapper=document.querySelector(".arrow-wrapper");
  var menu=document.querySelector(".menu");
  var toggle=true;
  arrow.addEventListener("click", ()=> {
      toggle=!toggle;
    if (toggle) {
      arrow.classList.add("arrow_flip");
      arrow.classList.remove("tip");
      arrow_wrapper.classList.add("wrapper-move");
      menu.classList.add("menu_active");
    }
    else {
      arrow.classList.remove("arrow_flip");
      //arrow.classList.add("tip");
      menu.classList.remove("menu_active");
    }
  });
}